const express = require("express");
const server = express();

server.get('/',(req, res, next) => {
    return res.status(200).send({
        mensagem: "Servidor funcionando!"
    })
})

server.listen(3000, () => {
    console.log("Executando")
})
