const express = require("express");
const servidor = express();
const mysql = require("mysql2");
const banco = mysql.createPool({
  database: "2e_ga_210922",
  user: "root",
  password: "LULILo04",
  host: "localhost",
  port: 3306,
});

const bodyParser = require("body-parser");
// const Query = require("mysql2/typings/mysql/lib/protocol/sequences/Query");

servidor.use(bodyParser.urlencoded({ extended: false }));
servidor.use(bodyParser.json());

//1° Questão

servidor.post("/cadastro", (req, res, next) => {
  let body = req.body;
  
  const QUERY = `INSERT INTO veiculos (modelo, marca, preco_venda, proprietario) VALUES('${body.modelo}', '${body.marca}', ${body.preco_venda}, '${body.proprietario}')`;

  banco.getConnection((error, conn) => {
    if (error) {
      return res
        .status(500)
        .send({ Mensagem: "Erro no servidor", Detalhes: error });
    }
    conn.query(QUERY, (error, resultado) => {
      conn.release();
      if (error) {
        return res
          .status(500)
          .send({ Mensagem: "Erro no servidor", Detalhes: error });
      }
      return res
        .status(200)
        .send({ Verbo: "post", Mensagem: "Veiculo cadastro realizado com sucesso!" });
    });
  });
});

//2° Questão

servidor.get("/veiculo", (req, res, next) => {
  const QUERY = "SELECT * FROM veiculos ORDER BY marca";

  banco.getConnection((error, conn) => {
    if (error) {
      return res.status(500).send({
        Erro: "Não foi possível atender à solicitação",
        Detalhes: error,
      });
    }
    conn.query(QUERY, (error, resultado) => {
      conn.release();
      if (error) {
        return res.status(500).send({
          Erro: "Não foi possível atender à solicitação",
          Detalhes: error,
        });
      }
      return res
        .status(200)
        .send({ Mensagem: "Exibição dos veiculos retornados com sucesso", Dados: resultado });
    });
  });
});

//3° Questão

servidor.get("/veiculos/:criterio", (req, res, next) => {
  let criterio = req.params.criterio;

  const QUERY = `SELECT * FROM veiculos WHERE marca LIKE '%${criterio}%' ORDER BY marca`;

  banco.getConnection((error, conn) => {
    if (error) {
      return res.status(500).send({
        Erro: "Não foi possivel atender à solicitação",
        Detalhes: error,
      });
    }

    conn.query(QUERY, (error, resultado) => {
      conn.release();

      if (error) {
        return res.status(500).send({
          Erro: "Não foi possivel atender à solicitação",
          Detalhes: error,
        });
      }

      return res.status(200).send({
        Mensagem: "Exibição dos veiculos retornados com sucesso",
        Detalhes: resultado,
      });
    });
  });
});

//4° Questão

servidor.get("/proprietarios/:criterio", (req, res, next) => {
  let criterio = req.params.criterio;
  const QUERY = `SELECT * FROM veiculos WHERE proprietario LIKE '%${criterio}%' ORDER BY proprietario`;

  banco.getConnection((error, conn) => {
    if (error) {
      return res.status(500).send({
        Erro: "Não foi possivel atender à solicitação",
        Detalhes: error,
      });
    }

    conn.query(QUERY, (error, resultado) => {
      conn.release();

      if (error) {
        return res.status(500).send({
          Erro: "Não foi possivel atender à solicitação",
          Detalhes: error,
        });
      }

      return res.status(200).send({
        Mensagem: "Exibição dos veiculos retornados com sucesso",
        Detalhes: resultado,
      });
    });
  });
});

//5° Questão

servidor.get("/veiculo/:preco", (req, res) => {
  let preco = req.params.preco;

  const QUERY = `SELECT * FROM veiculos WHERE preco_venda  >= ${preco}`;
  banco.getConnection((error, conn) => {
    if (error) {
      return res.status(500).send({
        Erro: "Não foi possível atender à solicitação",
        Detalhes: error,
      });
    }
    conn.query(QUERY, (error, resultado) => {
    conn.release();

      if (error) {
        return res.status(500).send({
          Erro: "Não foi possível atender à solicitação",
          Detalhes: error,
        });
      }
      return res
        .status(200)
        .send({ Mensagem: "Consulta realizada com sucesso", Dados: resultado });
    });
  });
});

//6° Questão

servidor.patch("/alterar/:id", (req, res, next) => {
  let id = req.params.id;
  let body = req.body;
  const SQL = `UPDATE veiculos SET marca = '${body.marca}', modelo = '${body.modelo}', preco_venda = ${body.preco_venda}, proprietario = '${body.proprietario}' WHERE veiculos.id = ${id}`;
  banco.getConnection((erro, con) => {
    if (erro) {
      return res
        .status(500)
        .send({ mensagem: "Erro no servidor", detalhes: erro });
    }

    con.query(SQL, (erro, result) => {
    con.release();

      if (erro) {
        return res
          .status(500)
          .send({ mensagem: "Erro ao atualizar o cadastro", detalhes: erro });
      }
      return res
        .status(200)
        .send({ mensagem: "Veiculo atualizado com sucesso!" });
    });
  });
});

//7° Questão

servidor.delete("/Deletar/:id", (req, res, next) => {
  let id = req.params.id;
  const QUERY = `DELETE FROM veiculos WHERE id = ${id}`;

  banco.getConnection((error, conn) => {
    if (error) {
      return res.status(500).send({
        Mensagem: "Erro no servidor",
        detalhes: error,
      });
    }

    conn.query(QUERY, (erro, resultado) => {
      conn.release();

      if (erro) {
        return res.status(500).send({
          Mensagem: `Não foi possivel excluir o Veiculo ${id}`,
          detalhes: erro,
        });
      }

      if (resultado.affectedRows > 0) {
        return res.status(200).send({
          Mensagem: `Veiculo ${id} excluido com sucesso`,
        });

      } else {
        return res.status(200).send({
          Mensagem: `Veiculo ${id} não existente no banco de dados`,
        });
      }
    });
  });
});

//8° Questão

servidor.delete("/Deletar_por_marca/:marcaV", (req, res, next) => {
  let marcaV = req.params.marcaV;
  const QUERY = `DELETE FROM veiculos WHERE marca = '${marcaV}'`;

  banco.getConnection((error, conn) => {
    if (error) {
      return res.status(500).send({
        Mensagem: "Erro no servidor",
        detalhes: error,
      });
    }

    conn.query(QUERY, (erro, resultado) => {
      conn.release();

      if (erro) {
        return res.status(500).send({
          Mensagem: `Não foi possivel excluir o Veiculo ${marcaV}`,
          detalhes: erro,
        });
      }

      if (resultado.affectedRows > 0) {
        return res.status(200).send({
          Mensagem: `Veiculo ${marcaV} excluido com sucesso`,
        });
      } 

      else {
        return res.status(200).send({
          Mensagem: `Veiculo ${marcaV} não existente no banco de dados`,
        });
      }
    });
  });
});

//9° Questão

servidor.delete("/deletar/:modelo/:preco",
  (req, res, next) => {
    let modelo = req.params.modelo;
    let preco = req.params.preco;

    const QUERY = `DELETE FROM veiculos WHERE modelo = '${modelo}' AND preco_venda >= ${preco}`;
    banco.getConnection((error, conn) => {

      if (error) {
        return res
          .status(500)
          .send({ mensagem: "Erro no servidor", detalhes: error });
      }

      conn.query(QUERY, (erro, resultados) => {
        conn.release();

        if (erro) {
          return res.status(500).send({
            mensagem: `Não foi possível excluir o veículo ${modelo}`,
            detalhes: erro,
          });
        }

        if (resultados.affectedRows > 0) {
          return res
            .status(200)
            .send({ mensagem: `O veículo ${modelo} excluído com sucesso` });

        } 
        else{
          return res.status(200).send({
            mensagem: `O veículo ${modelo} não existe no banco de dados`,
          });
        }
      });
    });
  }
);

servidor.listen(3100, () => {
  console.log("Executando");
});
