const express = require("express");
const servidor = express();
const mysql = require("mysql2");
const banco = mysql.createPool({
  database: "2e_ga_210922",
  user: "root",
  password: "LULILo04",
  host: "localhost",
  port: 3306,
});

const bodyParser = require("body-parser");

servidor.use(bodyParser.urlencoded({ extended: false }));
servidor.use(bodyParser.json());

servidor.post("/cadastro", (req, res, next) => {
  let body = req.body;
  const QUERY = `INSERT INTO veiculos (modelo, marca, preco_venda, proprietario) VALUES('${body.modelo}', '${body.marca}', ${body.preco_venda}, '${body.proprietario}')`;

  banco.getConnection((error, conn) => {
    if (error) {
      return res
        .status(500)
        .send({ Mensagem: "Erro no servidor", Detalhes: error });
    }
    conn.query(QUERY, (error, resultado) => {
      conn.release();
      if (error) {
        return res
          .status(500)
          .send({ Mensagem: "Erro no servidor", Detalhes: error });
      }
      return res
        .status(200)
        .send({ Verbo: "post", Mensagem: "Cadastro realizado com sucesso!" });
    });
  });
});

servidor.get("/veiculos",(req, res, next) =>{
  const QUERY = 'SELECT * FROM veiculos ORDER BY marca'

  banco.getConnection(error, conn) =>{
    if(erro)
  }

})

// servidor.get("/exibirVeiculos/:marca", (req, res, next) => {
//   let marca = req.params.marca;
//   let body = req.body;

//   const SQL = `SELECT*FROM veiculos = '${body.modelo}', marca = '${body.marca}', preco_venda = ${body.preco_venda} proprietario = '${body.proprietario}' WHERE marca = '${marca}'`;
//   banco.getConnection((erro, con) => {
//     if (erro) {
//       return res
//         .status(500)
//         .send({ mensagem: "Erro no servidor", detalhes: erro });
//     }
//     con.query(SQL, (erro, result) => {
//       con.release();
//       if (erro) {
//         return res
//           .status(500)
//           .send({ mensagem: "Erro ao atualizar o cadastro", detalhes: erro });
//       }
//       return res
//         .status(200)
//         .send({ mensagem: "Carro atualizado com sucesso!" });
//     });
//   });
// });

servidor.listen(3100, () => {
  console.log("Executando");
});
