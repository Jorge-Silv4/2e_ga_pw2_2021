const express = require("express");
const server = express();
const msql = require('mysql2')
const bacno = msql.createPool({
    host:'localhost',
    port: 3306,
    database: '2e_ga_2021',
    user: 'root',
    password: 'LULILo04'
})

server.get('/clientes', (req, res) =>{
    const SQL = 'SELECT * FROM clientes'

    bacno.getConnection((erro, con) =>{
        if(erro){
            return res.status(500).send({
                mensagem: 'Erro no servidor',
                detalhes: erro
            })
        }

        con.query(SQL, (erro, resultado) => {
            con.release()

            if(erro){
                return res.status(500).send({
                    mensagem: 'Erro de consulta',
                    detalhes: erro
                })
            }

            return res.status(200).send({
                mensagem: 'Dados carregados com sucesso',
                data: resultado
            })

        })

    })

})

server.get('/testarconexao', (req, res) =>{
    bacno.getConnection((erro, con) => {

        if(erro){
            return res.status(500).send({
                mensagem: 'Erro no servidor',
                detalhes: erro
            })
        }

        return res.status(200).send({
            mensagem: 'Conexão estabelecida com sucesso'
        })

    })
})

server.get('/',(req, res, next) => {
    return res.status(200).send({
        mensagem: "Servidor funcionando!"
    })
})

server.listen(3000, () => {
    console.log("Executando")
})
